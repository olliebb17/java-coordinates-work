
package coordinatescode;
import java.util.Random;
import java.util.Scanner;

public class Coordinatescode {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("what is the x coordinate?");
        int x = input.nextInt();
        System.out.println("what is the y coordinate?");
        int y = input.nextInt();
        String [] [] board = new String[10][8];
     for (int i = 0; i < 10; i++) {
         for (int j = 0; j < 8; j++){
             board[i][j] = "[]";
             System.out.print(board[i][j]);
         
         }
         System.out.println("");
     }
    
      
    }
    
    
    
}
